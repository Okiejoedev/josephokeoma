# Daily Sales Report for Field Sales Teams (n8n)

Field reps submit their sales on a Google Form. Every day at 6pm Lagos time, n8n totals the day's sales in Naira by region, market and product, and emails managers a clean report. Nobody types anything up.

**Built with:** Google Forms · Google Sheets · n8n · Gmail. Four nodes, core n8n only.

![Email preview](email-preview.png)

## What's in this folder

| File | What it is |
| --- | --- |
| `daily-sales-report-workflow.json` | The n8n workflow. Import it directly. |
| `sample-sales-data.csv` | 49 made-up submissions across 8 Lagos markets, for testing |
| `report.js` | The report logic (already inside the workflow; here for reading) |
| `email-preview.png` | What managers receive |

## Set it up (about 15 minutes)

### 1. Make the Google Form

Create a form with these questions. The names must match exactly, because the workflow reads them as column headers.

| Question | Type |
| --- | --- |
| Promoter name | Short answer |
| Region | Dropdown (e.g. Lagos Island, Mainland, Ikeja, Lekki) |
| Market | Dropdown or short answer |
| Product | Dropdown, using exactly the product names in your price list |
| Quantity sold | Short answer, with number validation |

Google adds the **Timestamp** column by itself.

### 2. Link it to a Google Sheet

In the form, go to **Responses → Link to Sheets**. Then, in the sheet, open **File → Settings** and set:

- **Locale:** Nigeria (or United Kingdom), so dates show as DD/MM/YYYY
- **Time zone:** (GMT+01:00) Lagos

Copy the sheet ID from its URL: the long code between `/d/` and `/edit`.

### 3. Import into n8n

1. In n8n, choose **Import from file** and select `daily-sales-report-workflow.json`.
2. Open **Read form responses**: connect your Google Sheets account and paste your sheet ID.
3. Open **Email the managers**: connect your Gmail account and put the managers' emails in **To** (separate several with commas).
4. Open **Build report**: edit the settings at the top: your price list in Naira (`PRICES`) and the manager's name.

If you self-host n8n, also set the environment variable `GENERIC_TIMEZONE=Africa/Lagos`. The workflow already sets its own time zone to Lagos.

### 4. Test with the sample data

1. Make a copy of your response sheet, or use a test sheet, and paste in `sample-sales-data.csv`.
2. In **Build report**, set `TEST_DATE = '28/10/2026'`.
3. Click **Execute workflow**. You should get an email showing ₦927,500 from 8 promoters.
4. Set `TEST_DATE` back to `''` and point the workflow at your real sheet.

### 5. Switch it on

Toggle the workflow to **Active**. From then on the report arrives at 6pm every day. To change the time, edit **Every day at 6pm**.

## Things it handles

- **Lagos time, not server time.** "Today" is worked out in Africa/Lagos, so late submissions don't fall into the wrong day.
- **DD/MM dates.** Set `DATE_ORDER = 'MDY'` if your sheet shows US-style dates.
- **No submissions.** Managers get a short "no sales submitted today" email instead of nothing.
- **Unknown products.** Rows with a product missing from the price list are skipped and named at the bottom of the email, so nothing disappears silently.

## Notes

All names, markets, products and prices in the sample data are made up.

Built by Joseph Okeoma, Lagos. Want this running for your sales team? Message me.
