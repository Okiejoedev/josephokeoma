// ===== SETTINGS (edit these) =====
const MANAGER_NAME = 'Sales Manager';
const TEST_DATE = '';            // leave '' for today. For a demo, put a date like '28/10/2026'
const DATE_ORDER = 'DMY';        // how your sheet shows dates: 'DMY' (27/10/2026) or 'MDY' (10/27/2026)
const PRICES = {                 // unit price in Naira for each product on your form
  'Detergent 500g': 1200,
  'Bar Soap 150g': 450,
  'Toothpaste 140g': 900,
  'Body Cream 200ml': 1500,
  'Liquid Soap 1L': 1800,
  'Hair Pomade 100g': 700,
};
// =================================

const naira = n => '₦' + Math.round(n).toLocaleString('en-US');
const pad = n => String(n).padStart(2, '0');

// Today's date in Lagos, as DD/MM/YYYY
const lagos = new Intl.DateTimeFormat('en-GB', { timeZone: 'Africa/Lagos', day: '2-digit', month: '2-digit', year: 'numeric' })
  .format(new Date());
const reportDate = TEST_DATE || lagos;

// Turn a sheet timestamp into DD/MM/YYYY
function dayOf(ts) {
  const m = String(ts || '').match(/(\d{1,4})[\/\-](\d{1,2})[\/\-](\d{1,4})/);
  if (!m) return '';
  let [, a, b, c] = m;
  if (a.length === 4) return `${pad(c)}/${pad(b)}/${a}`;          // YYYY-MM-DD
  return DATE_ORDER === 'MDY' ? `${pad(b)}/${pad(a)}/${c}` : `${pad(a)}/${pad(b)}/${c}`;
}

const rows = $input.all().map(i => i.json).filter(r => dayOf(r['Timestamp']) === reportDate);

const byMarket = {}, bySku = {}, promoters = new Set();
let units = 0, revenue = 0;
const unknown = new Set();

for (const r of rows) {
  const sku = String(r['Product'] || '').trim();
  const qty = Number(String(r['Quantity sold'] || 0).replace(/[^\d.]/g, '')) || 0;
  const price = PRICES[sku];
  if (price === undefined) { unknown.add(sku || '(blank)'); continue; }
  const value = qty * price;
  const region = String(r['Region'] || 'Unknown').trim();
  const market = String(r['Market'] || 'Unknown').trim();
  const key = region + '|' + market;
  byMarket[key] = byMarket[key] || { region, market, units: 0, revenue: 0 };
  byMarket[key].units += qty; byMarket[key].revenue += value;
  bySku[sku] = bySku[sku] || { units: 0, revenue: 0 };
  bySku[sku].units += qty; bySku[sku].revenue += value;
  units += qty; revenue += value;
  if (r['Promoter name']) promoters.add(String(r['Promoter name']).trim());
}

const markets = Object.values(byMarket).sort((a, b) => a.region.localeCompare(b.region) || b.revenue - a.revenue);
const skus = Object.entries(bySku).sort((a, b) => b[1].revenue - a[1].revenue);
const top = [...markets].sort((a, b) => b.revenue - a.revenue)[0];

const th = 'style="text-align:left;padding:8px 10px;background:#0b6e4f;color:#fff;font-size:13px"';
const thr = 'style="text-align:right;padding:8px 10px;background:#0b6e4f;color:#fff;font-size:13px"';
const td = 'style="padding:8px 10px;border-bottom:1px solid #e5e5e5;font-size:13px"';
const tdr = 'style="padding:8px 10px;border-bottom:1px solid #e5e5e5;font-size:13px;text-align:right"';
const card = (label, value) => `<td style="padding:12px 14px;background:#f2f8f5;border-radius:8px;width:33%"><div style="font-size:12px;color:#5f6368">${label}</div><div style="font-size:20px;font-weight:700;color:#1d1d1f;margin-top:4px">${value}</div></td>`;

let body;
if (!rows.length) {
  body = `<p style="font-size:14px">No sales were submitted on ${reportDate}.</p>`;
} else {
  body = `
<table cellspacing="8" style="width:100%;border-collapse:separate"><tr>
${card('Total sales', naira(revenue))}${card('Units sold', units.toLocaleString('en-US'))}${card('Promoters who reported', promoters.size)}
</tr></table>
${top ? `<p style="font-size:14px;margin:14px 0">Top market today: <b>${top.market}</b> (${top.region}) with <b>${naira(top.revenue)}</b>.</p>` : ''}
<h3 style="font-size:15px;margin:20px 0 8px">By region and market</h3>
<table style="width:100%;border-collapse:collapse"><tr><th ${th}>Region</th><th ${th}>Market</th><th ${thr}>Units</th><th ${thr}>Sales</th></tr>
${markets.map(m => `<tr><td ${td}>${m.region}</td><td ${td}>${m.market}</td><td ${tdr}>${m.units.toLocaleString('en-US')}</td><td ${tdr}>${naira(m.revenue)}</td></tr>`).join('')}
</table>
<h3 style="font-size:15px;margin:20px 0 8px">By product</h3>
<table style="width:100%;border-collapse:collapse"><tr><th ${th}>Product</th><th ${thr}>Units</th><th ${thr}>Sales</th></tr>
${skus.map(([s, v]) => `<tr><td ${td}>${s}</td><td ${tdr}>${v.units.toLocaleString('en-US')}</td><td ${tdr}>${naira(v.revenue)}</td></tr>`).join('')}
</table>
${unknown.size ? `<p style="font-size:12px;color:#b3261e;margin-top:14px">Skipped entries with products not in the price list: ${[...unknown].join(', ')}. Add them to PRICES in the Code node.</p>` : ''}`;
}

const html = `<div style="font-family:Arial,Helvetica,sans-serif;max-width:640px;color:#1d1d1f">
<div style="background:#0b6e4f;color:#fff;padding:18px 20px;border-radius:8px 8px 0 0"><div style="font-size:12px;opacity:.85">End-of-day sales report</div><div style="font-size:22px;font-weight:700;margin-top:4px">${reportDate}</div></div>
<div style="padding:16px 20px;border:1px solid #e5e5e5;border-top:none;border-radius:0 0 8px 8px">
<p style="font-size:14px">Good evening ${MANAGER_NAME}, here is today's field sales summary.</p>
${body}
<p style="font-size:11px;color:#888;margin-top:20px">Sent automatically at close of day (Lagos time).</p></div></div>`;

const subject = rows.length
  ? `Sales report ${reportDate}: ${naira(revenue)} from ${promoters.size} promoters`
  : `Sales report ${reportDate}: no submissions`;

return [{ json: { subject, html, reportDate, totalRevenue: revenue, totalUnits: units, submissions: rows.length } }];
